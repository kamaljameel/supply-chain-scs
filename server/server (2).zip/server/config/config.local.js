module.exports = {
    username: "root",
    password: "",
    database: "ecomapi",
    host: "localhost",
    dialect: "mysql",
  };
  