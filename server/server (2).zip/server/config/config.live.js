module.exports = {
  username: "iscspczw_root",
  password: "$KMH9hSYmQUj",
  database: "iscspczw_iscs",
  host: "localhost",
  dialect: "mysql",
};
