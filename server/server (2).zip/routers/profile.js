// routes/profile.js

// const express = require("express");
// const verifyToken = require("../middleware/authMiddleware");
// const router = express.Router();

// // Example protected route
// router.get("/", verifyToken, (req, res) => {
//   // req.user contains the user object from database
//   const { id, name, email } = req.user;
//   res.json({ id, name, email });
// });

// module.exports = router;
